import React from "react";

// This file is no longer used as the main app component
// Routing is now handled in main.tsx
export default function App() {
  return <div>Legacy App component - should not be rendered</div>;
}
